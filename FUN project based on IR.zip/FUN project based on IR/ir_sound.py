import serial
import time
import threading
import sys
import os

try:
    import pygame
except ImportError:
    print("ERROR: pygame not installed!")
    print("Run: pip install pygame")
    sys.exit(1)

# Audio initialization
pygame.mixer.pre_init(22050, -16, 2, 512)
pygame.mixer.init()

def play_alarm():
    """Play bhago.mp3 alarm sound"""
    try:
        if os.path.exists("bhago.mp3"):
            pygame.mixer.music.load("bhago.mp3")
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
            print("✅ Alarm finished")
        else:
            print("❌ ERROR: bhago.mp3 not found in current folder!")
    except Exception as e:
        print(f"❌ Audio error: {e}")

# Find Arduino port automatically
import serial.tools.list_ports as list_ports
ports = list_ports.comports()
arduino_port = None

for port in ports:
    desc = port.description.lower()
    if any(keyword in desc for keyword in ['arduino', 'ch340', 'ch341', 'usb-serial', 'ftdi']):
        arduino_port = port.device
        break

if not arduino_port:
    print("❌ ERROR: No Arduino found!")
    print("Available ports:")
    for p in ports:
        print(f"  {p.device}: {p.description}")
    sys.exit(1)

print(f"✅ Connected: {arduino_port}")
ser = serial.Serial(arduino_port, 9600, timeout=1.0)
time.sleep(3)  # Arduino reset time

last_alarm_time = 0
print("🚀 IR ALARM SYSTEM ACTIVE")
print("📱 Cover IR sensor → ALARM every 60 seconds")
print("Ctrl+C to stop")

try:
    while True:
        line = ser.readline().decode('utf-8', errors='ignore').rstrip()
        
        if line == "DETECT":
            now = time.time()
            if now - last_alarm_time >= 60:  # 1 minute cooldown
                print("🔊 ALARM TRIGGERED!")
                alarm_thread = threading.Thread(target=play_alarm, daemon=True)
                alarm_thread.start()
                last_alarm_time = now
            else:
                remaining = int(60 - (now - last_alarm_time))
                print(f"⏳ Alarm cooldown: {remaining}s remaining")
                
        elif line.strip():  # Print other messages for debugging
            print(f"Arduino: {line}")
            
except KeyboardInterrupt:
    print("\n🛑 Stopped by user")
except Exception as e:
    print(f"❌ Error: {e}")
finally:
    ser.close()
    pygame.mixer.quit()
    print("👋 Disconnected - Goodbye!")
